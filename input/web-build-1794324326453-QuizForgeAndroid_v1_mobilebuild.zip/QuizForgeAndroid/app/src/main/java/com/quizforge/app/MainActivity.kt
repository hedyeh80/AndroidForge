package com.quizforge.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.util.regex.Pattern

data class QuizQuestion(val prompt: String, val options: List<String>, val correct: Int, val explanation: String)

class MainActivity : Activity() {
    private val bg = Color.rgb(16,16,27)
    private val panel = Color.rgb(30,29,48)
    private val purple = Color.rgb(181,108,255)
    private val cyan = Color.rgb(68,220,220)
    private val white = Color.rgb(245,242,255)
    private val muted = Color.rgb(175,170,195)
    private val prefs by lazy { getSharedPreferences("quizforge", MODE_PRIVATE) }
    private val quizzes = mutableListOf<Pair<String, MutableList<QuizQuestion>>>()
    private var activeQuestions: List<QuizQuestion> = emptyList()
    private var index = 0
    private var score = 0
    private var selected = -1
    private var answered = false
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSaved()
        showHome()
    }

    private fun base(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(bg)
        }
        val scroller = ScrollView(this).apply { addView(root) }
        setContentView(scroller)
        text(title, 27, white, true)
        if (subtitle != null) text(subtitle, 14, muted, false)
        space(16)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) {
        root.addView(TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        })
    }

    private fun space(h: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun button(label: String, action: () -> Unit, accent: Boolean = false) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (accent) Color.BLACK else white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (accent) cyan else panel))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) })
    }

    private fun input(hint: String, multi: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
            inputType = if (multi) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
            if (multi) { minLines = 8; gravity = Gravity.TOP }
        }
        root.addView(e, LinearLayout.LayoutParams(-1, if (multi) dp(230) else dp(54)).apply { bottomMargin = dp(12) })
        return e
    }

    private fun showHome() {
        base("⚡ QUIZFORGE", "ARENA MODE  •  آفلاین، سریع و همیشه در دسترس")
        val total = quizzes.sumOf { it.second.size }
        text("آماده‌ای رکورد بزنی؟", 21, white, true)
        text("$total سؤال ذخیره‌شده  •  ${quizzes.size} مجموعه آزمون", 14, cyan, true)
        space(12)
        button("＋  ساخت آزمون جدید", { showImport() }, true)
        button("🎮  کتابخانه آزمون‌ها", { showLibrary() })
        button("📦  راهنمای قالب ورود سؤال", { showFormat() })
        space(12)
        text("ویژگی‌ها", 18, purple, true)
        text("• اجرای آزمون و تصحیح خودکار\n• نمایش پاسخ تشریحی پس از هر سؤال\n• ذخیره محلی مجموعه‌ها\n• ورود متن یا JSON\n• بدون نیاز به اینترنت", 14, muted, false)
    }

    private fun showImport() {
        base("ساخت آزمون", "نام مجموعه را بنویس و متن سؤال‌ها یا JSON را وارد کن.")
        val name = input("مثلاً: فارسی دوازدهم")
        val data = input("متن سؤال‌ها یا آرایه JSON را اینجا بچسبان…", true)
        button("⚡ تبدیل متن به آزمون", {
            val parsed = parseText(data.text.toString())
            if (parsed.isEmpty()) toast("سؤالی پیدا نشد. قالب نمونه را ببین.")
            else saveQuiz(name.text.toString().ifBlank { "آزمون ${quizzes.size + 1}" }, parsed)
        }, true)
        button("بازگشت", { showHome() })
    }

    private fun showFormat() {
        base("قالب‌های قابل ورود", "می‌توانی JSON استاندارد یا قالب کدنویسی سؤال‌ها را وارد کنی.")
        val sample = """[
  {
    "question": "«جبین» به چه معناست؟",
    "options": ["پیشانی", "زبان", "سینه", "درون قلب"],
    "correct": 0,
    "explanation": "جبین به معنای پیشانی است."
  }
]"""
        text(sample, 13, cyan, false)
        space(12)
        text("همچنین این قالب هم پشتیبانی می‌شود:", 14, white, true)
        text("""question: "معنی جبین چیست؟",
options: ["پیشانی", "زبان", "سینه", "قلب"],
correct: 0,
explanation: "جبین یعنی پیشانی." """, 13, muted, false)
        button("بازگشت", { showHome() })
    }

    private fun showLibrary() {
        base("کتابخانه آزمون‌ها", "مجموعه‌های ذخیره‌شده روی همین دستگاه")
        if (quizzes.isEmpty()) text("هنوز آزمونی نساختی.", 15, muted, false)
        quizzes.forEachIndexed { i, item ->
            button("🎯  ${item.first}  •  ${item.second.size} سؤال", { startQuiz(i) })
            button("حذف «${item.first}»", { quizzes.removeAt(i); persist(); showLibrary() })
        }
        button("بازگشت", { showHome() })
    }

    private fun startQuiz(i: Int) {
        activeQuestions = quizzes[i].second
        index = 0; score = 0; selected = -1; answered = false
        showQuestion()
    }

    private fun showQuestion() {
        if (index >= activeQuestions.size) { showResult(); return }
        val q = activeQuestions[index]
        base("⚡ ARENA  •  ${index + 1}/${activeQuestions.size}", "امتیاز: $score")
        text(q.prompt, 20, white, true)
        space(12)
        q.options.forEachIndexed { i, option ->
            button("${"ABCD".getOrElse(i) { '•' }}   $option", {
                if (!answered) { selected = i; answered = true; if (i == q.correct) score++; showQuestion() }
            }, selected == i)
        }
        if (answered) {
            val correct = selected == q.correct
            text(if (correct) "✨ آفرین! پاسخ درست بود." else "💥 این یکی درست نبود.", 17, if (correct) cyan else Color.rgb(255,125,145), true)
            text("پاسخ صحیح: ${q.options.getOrNull(q.correct) ?: ""}", 15, white, true)
            text(q.explanation.ifBlank { "برای این سؤال توضیحی ثبت نشده است." }, 14, muted, false)
            button(if (index == activeQuestions.lastIndex) "دیدن نتیجه نهایی" else "سؤال بعدی  →", {
                index++; selected = -1; answered = false; showQuestion()
            }, true)
        } else {
            text("یک گزینه را انتخاب کن.", 13, muted, false)
        }
        button("خروج از آزمون", { showHome() })
    }

    private fun showResult() {
        val percent = if (activeQuestions.isEmpty()) 0 else score * 100 / activeQuestions.size
        base("🏆 نتیجه مسابقه", "RUN COMPLETE")
        text("$score از ${activeQuestions.size}", 34, cyan, true)
        text("$percent٪ پاسخ صحیح", 21, white, true)
        text(when { percent >= 90 -> "افسانه‌ای! عالی جنگیدی." ; percent >= 70 -> "خیلی خوب بود! ادامه بده." ; percent >= 50 -> "رو به پیشرفتی؛ مرور کن." ; else -> "هر تلاش یک قدم جلوتره." }, 16, muted, false)
        button("دوباره امتحان بده", { index = 0; score = 0; selected = -1; answered = false; showQuestion() }, true)
        button("بازگشت به خانه", { showHome() })
    }

    private fun saveQuiz(name: String, questions: MutableList<QuizQuestion>) {
        quizzes.add(name to questions)
        persist()
        toast("${questions.size} سؤال با موفقیت اضافه شد.")
        showHome()
    }

    private fun parseText(raw: String): MutableList<QuizQuestion> {
        val out = mutableListOf<QuizQuestion>()
        // First try a JSON array.
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val q = fromJson(obj)
                if (q != null) out.add(q)
            }
            if (out.isNotEmpty()) return out
        } catch (_: Exception) {}
        // Accept JavaScript-like question objects with options, correct and explanation fields.
        val blocks = Regex("""(?s)\{.*?(?=\n\s*\}|\z)""").findAll(raw)
        for (m in blocks) {
            val block = m.value
            val prompt = field(block, "question") ?: field(block, "prompt") ?: field(block, "text") ?: continue
            val optionsRaw = Regex("""options\s*:\s*\[(.*?)]""", RegexOption.DOT_MATCHES_ALL).find(block)?.groupValues?.get(1) ?: continue
            val opts = Regex(""""((?:\\.|[^"\\])*)"""").findAll(optionsRaw).map { unescape(it.groupValues[1]) }.toList()
            val correct = Regex("""correct\s*:\s*(\d+)""").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val explanation = field(block, "explanation") ?: field(block, "feedback") ?: ""
            if (opts.size >= 2 && correct in opts.indices) out.add(QuizQuestion(prompt, opts, correct, explanation))
        }
        return out
    }

    private fun field(block: String, key: String): String? {
        val match = Regex("""$key\s*:\s*"((?:\\.|[^"\\])*)"""").find(block)
        return match?.groupValues?.get(1)?.let { unescape(it) }
    }

    private fun unescape(s: String) = s.replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\")

    private fun fromJson(o: JSONObject): QuizQuestion? {
        val prompt = o.optString("question", o.optString("prompt", ""))
        val a = o.optJSONArray("options") ?: return null
        val opts = (0 until a.length()).map { a.optString(it) }
        val correctValue = o.opt("correct")
        val correct = when (correctValue) {
            is Number -> correctValue.toInt()
            is String -> "ABCD".indexOf(correctValue.uppercase()).takeIf { it >= 0 } ?: correctValue.toIntOrNull() ?: -1
            else -> -1
        }
        if (prompt.isBlank() || opts.size < 2 || correct !in opts.indices) return null
        return QuizQuestion(prompt, opts, correct, o.optString("explanation", o.optString("feedback", "")))
    }

    private fun persist() {
        val arr = JSONArray()
        quizzes.forEach { (name, qs) ->
            val obj = JSONObject(); obj.put("name", name)
            val qarr = JSONArray()
            qs.forEach { q ->
                val qo = JSONObject(); qo.put("question", q.prompt); qo.put("correct", q.correct); qo.put("explanation", q.explanation)
                val opts = JSONArray(); q.options.forEach { opts.put(it) }; qo.put("options", opts); qarr.put(qo)
            }
            obj.put("questions", qarr); arr.put(obj)
        }
        prefs.edit().putString("quizzes", arr.toString()).apply()
    }

    private fun loadSaved() {
        try {
            val arr = JSONArray(prefs.getString("quizzes", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val qs = mutableListOf<QuizQuestion>()
                val qa = o.getJSONArray("questions")
                for (j in 0 until qa.length()) fromJson(qa.getJSONObject(j))?.let { qs.add(it) }
                quizzes.add(o.optString("name") to qs)
            }
        } catch (_: Exception) {}
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
