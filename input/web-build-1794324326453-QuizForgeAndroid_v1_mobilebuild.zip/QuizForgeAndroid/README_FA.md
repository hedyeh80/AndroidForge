# QuizForge — نسخه اولیه اندروید

## ساخت APK
این پروژه Kotlin + Android Gradle Plugin است. برای بیلد ابری از AndroidForge یا Android Studio استفاده کن.
در بیلد ابری، AndroidForge در صورت نبودن Gradle Wrapper تلاش می‌کند آن را بازسازی کند.

## قالب JSON
```json
[
  {
    "question": "«جبین» به چه معناست؟",
    "options": ["پیشانی", "زبان", "سینه", "درون قلب"],
    "correct": 0,
    "explanation": "جبین به معنای پیشانی است."
  }
]
```
`correct` شماره گزینه از صفر است.
